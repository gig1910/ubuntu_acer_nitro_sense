"""Pure-Python controller simulation used by the profile editor preview.

This module deliberately has no GTK dependency so the educational preview can
be regression-tested in packaging/build environments without PyGObject.

The simulation is illustrative, but it follows the profile semantics exposed by
Acer Control:
  * separate EMA coefficients for rising/falling temperature,
  * CPU down hysteresis before a lower fan step is accepted,
  * CPU down delay after the hysteresis condition is satisfied,
  * GPU native down delay after a lower native temperature target appears.

One simulation sample represents one second and one filter update.  The graph
labels this assumption explicitly; it is a visualization aid, not the runtime
controller itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence


Point = tuple[float, int]


@dataclass(frozen=True)
class DynamicsSample:
    t: float
    input_temp: float
    cpu_ema: float
    gpu_ema: float
    cpu_target: int
    cpu_output: int
    gpu_target: int
    gpu_output: int
    cpu_hold: str | None = None
    gpu_hold: str | None = None


def clamp_alpha(value: float) -> float:
    return max(0.001, min(1.0, float(value)))


def ema_next(current: float, target: float, alpha_up: float, alpha_down: float) -> float:
    up = clamp_alpha(alpha_up)
    down = clamp_alpha(alpha_down)
    alpha = up if target > current else down
    return alpha * target + (1.0 - alpha) * current


def normalized_curve(points: Iterable[tuple[float, float]]) -> list[Point]:
    curve = sorted((float(x), int(round(y))) for x, y in points)
    if not curve:
        return [(0.0, 0)]
    return curve


def curve_target(points: Sequence[Point], value: float) -> int:
    """Step lookup matching the threshold/node semantics shown by the editor.

    The first fan level is also used below the first threshold.  Each later
    node becomes active once its threshold is reached.
    """
    curve = normalized_curve(points)
    result = curve[0][1]
    for threshold, fan in curve:
        if value < threshold:
            break
        result = fan
    return int(result)


def threshold_for_output(points: Sequence[Point], output: int) -> float:
    """Return the threshold that introduced the current fan level.

    This provides the falling boundary used to visualize CPU hysteresis.
    """
    curve = normalized_curve(points)
    selected = curve[0][0]
    for threshold, fan in curve:
        if fan <= output:
            selected = threshold
        else:
            break
    return float(selected)


def default_temperature_scenario(seconds: int = 64) -> list[tuple[float, float]]:
    """A deterministic heat-up / cool-down scenario crossing all profile nodes."""
    result: list[tuple[float, float]] = []
    seconds = max(24, int(seconds))

    # 0..5: stable cool state
    # 6..22: smooth heat-up 52 -> 100 C
    # 23..28: hot plateau
    # 29..58: slower cool-down 100 -> 52 C
    # remainder: cool plateau
    for t in range(seconds + 1):
        if t <= 5:
            temp = 52.0
        elif t <= 22:
            frac = (t - 5) / 17.0
            temp = 52.0 + frac * 48.0
        elif t <= 28:
            temp = 100.0
        elif t <= 58:
            frac = (t - 28) / 30.0
            temp = 100.0 - frac * 48.0
        else:
            temp = 52.0
        result.append((float(t), float(temp)))
    return result


def simulate_dynamics(
    *,
    cpu_curve: Sequence[Point],
    gpu_curve: Sequence[Point],
    cpu_alpha_up: float,
    cpu_alpha_down: float,
    cpu_hysteresis: float,
    cpu_down_delay: float,
    gpu_alpha_up: float,
    gpu_alpha_down: float,
    gpu_down_delay: float,
    scenario: Sequence[tuple[float, float]] | None = None,
) -> list[DynamicsSample]:
    """Simulate the visual controller response for the editor graph."""
    cpu_curve_n = normalized_curve(cpu_curve)
    gpu_curve_n = normalized_curve(gpu_curve)
    scenario = list(scenario or default_temperature_scenario())
    if not scenario:
        return []

    hysteresis = max(0.0, float(cpu_hysteresis))
    cpu_delay = max(0.0, float(cpu_down_delay))
    gpu_delay = max(0.0, float(gpu_down_delay))

    first_temp = float(scenario[0][1])
    cpu_filtered = first_temp
    gpu_filtered = first_temp
    cpu_output = curve_target(cpu_curve_n, cpu_filtered)
    gpu_output = curve_target(gpu_curve_n, gpu_filtered)

    cpu_down_since: float | None = None
    gpu_down_since: float | None = None
    result: list[DynamicsSample] = []

    for index, (t, input_temp) in enumerate(scenario):
        t = float(t)
        input_temp = float(input_temp)
        if index:
            cpu_filtered = ema_next(
                cpu_filtered,
                input_temp,
                cpu_alpha_up,
                cpu_alpha_down,
            )
            gpu_filtered = ema_next(
                gpu_filtered,
                input_temp,
                gpu_alpha_up,
                gpu_alpha_down,
            )

        cpu_target = curve_target(cpu_curve_n, cpu_filtered)
        gpu_target = curve_target(gpu_curve_n, gpu_filtered)
        cpu_hold: str | None = None
        gpu_hold: str | None = None

        # Rising output is intentionally immediate once the filtered input
        # reaches the next curve threshold.
        if cpu_target >= cpu_output:
            cpu_output = cpu_target
            cpu_down_since = None
        else:
            boundary = threshold_for_output(cpu_curve_n, cpu_output) - hysteresis
            if cpu_filtered > boundary:
                cpu_down_since = None
                cpu_hold = "hysteresis"
            else:
                if cpu_down_since is None:
                    cpu_down_since = t
                elapsed = t - cpu_down_since
                if elapsed + 1e-9 >= cpu_delay:
                    cpu_output = cpu_target
                    cpu_down_since = None
                else:
                    cpu_hold = "down_delay"

        # GPU temperature path has no separate hysteresis parameter in the
        # current profile.  Its native down delay is shown directly.
        if gpu_target >= gpu_output:
            gpu_output = gpu_target
            gpu_down_since = None
        else:
            if gpu_down_since is None:
                gpu_down_since = t
            elapsed = t - gpu_down_since
            if elapsed + 1e-9 >= gpu_delay:
                gpu_output = gpu_target
                gpu_down_since = None
            else:
                gpu_hold = "native_down_delay"

        result.append(
            DynamicsSample(
                t=t,
                input_temp=input_temp,
                cpu_ema=cpu_filtered,
                gpu_ema=gpu_filtered,
                cpu_target=cpu_target,
                cpu_output=cpu_output,
                gpu_target=gpu_target,
                gpu_output=gpu_output,
                cpu_hold=cpu_hold,
                gpu_hold=gpu_hold,
            )
        )

    return result
