#!/usr/bin/env python3

import subprocess
import sys
import time

from gi.repository import Gio, GLib

from .config import ConfigError, ConfigStore
from .hardware import (
    AcerHardware,
    HardwareError,
)
from .keyboard_hw import (
    AcerKeyboardHardware,
    KeyboardConfigError,
    KeyboardConfigStore,
    KeyboardController,
    KeyboardHardwareError,
    KeyboardState,
    ZONE_NAMES,
)


BUS_NAME = "org.acer.Control"
OBJECT_PATH = "/org/acer/Control"
INTERFACE_NAME = "org.acer.Control"
POLKIT_ACTION_MODIFY = "org.acer.control.modify"


INTROSPECTION_XML = """
<node>
  <interface name="org.acer.Control">

    <signal name="TelemetryChanged">
      <arg name="telemetry" type="a{sv}"/>
    </signal>

    <method name="SetPlatformProfile">
      <arg name="profile" type="s" direction="in"/>
      <arg name="profile" type="s" direction="out"/>
    </method>

    <method name="SavePlatformProfile">
      <arg name="profile" type="s" direction="in"/>
      <arg name="profile" type="s" direction="out"/>
    </method>

    <method name="GetSavedPlatformProfile">
      <arg name="profile" type="s" direction="out"/>
    </method>

    <method name="GetTelemetry">
      <arg name="telemetry" type="a{sv}" direction="out"/>
    </method>

    <method name="GetCapabilities">
      <arg name="capabilities" type="a{sv}" direction="out"/>
    </method>

    <method name="ListFanProfiles">
      <arg name="profiles" type="as" direction="out"/>
    </method>

    <method name="GetFanProfile">
      <arg name="name" type="s" direction="in"/>
      <arg name="config" type="s" direction="out"/>
    </method>

    <method name="ValidateFanProfile">
      <arg name="name" type="s" direction="in"/>
      <arg name="config" type="s" direction="in"/>
      <arg name="valid" type="b" direction="out"/>
      <arg name="message" type="s" direction="out"/>
    </method>

    <method name="GetActiveFanProfile">
      <arg name="platform_profile" type="s" direction="out"/>
      <arg name="fan_profile" type="s" direction="out"/>
    </method>

    <method name="SaveFanProfile">
      <arg name="name" type="s" direction="in"/>
      <arg name="config" type="s" direction="in"/>
      <arg name="saved" type="b" direction="out"/>
    </method>

    <method name="DeleteFanProfile">
      <arg name="name" type="s" direction="in"/>
      <arg name="deleted" type="b" direction="out"/>
    </method>

    <method name="SetActiveFanProfile">
      <arg name="name" type="s" direction="in"/>
      <arg name="active_profile" type="s" direction="out"/>
    </method>

    <method name="GetFollowPlatformProfile">
      <arg name="enabled" type="b" direction="out"/>
    </method>

    <method name="SetFollowPlatformProfile">
      <arg name="enabled" type="b" direction="in"/>
      <arg name="enabled" type="b" direction="out"/>
    </method>

    <method name="GetKeyboardLighting">
      <arg name="state" type="a{sv}" direction="out"/>
    </method>

    <method name="BeginKeyboardLightingPreview">
      <arg name="state" type="a{sv}" direction="out"/>
    </method>

    <method name="PreviewKeyboardLighting">
      <arg name="state" type="a{sv}" direction="in"/>
      <arg name="state" type="a{sv}" direction="out"/>
    </method>

    <method name="SaveKeyboardLighting">
      <arg name="state" type="a{sv}" direction="in"/>
      <arg name="state" type="a{sv}" direction="out"/>
    </method>

    <method name="CancelKeyboardLightingPreview">
      <arg name="state" type="a{sv}" direction="out"/>
    </method>

  </interface>
</node>
"""


class AcerControlDaemon:
    def __init__(self):
        self.store = ConfigStore()
        self.hardware = AcerHardware()
        self.keyboard = KeyboardController(
            AcerKeyboardHardware(),
            KeyboardConfigStore(),
        )
        self.keyboard_preview_baselines = {}

        main_config = self.store.load_main()

        self.sample_interval = main_config.getfloat(
            "general",
            "sample_interval",
            fallback=1.0,
        )

        self.gpu_poll_interval = main_config.getfloat(
            "general",
            "gpu_poll_interval",
            fallback=2.0,
        )

        if self.sample_interval <= 0:
            raise ConfigError(
                "general.sample_interval must be > 0"
            )

        if self.gpu_poll_interval <= 0:
            raise ConfigError(
                "general.gpu_poll_interval must be > 0"
            )

        self.telemetry = {}
        self.gpu_telemetry = None
        self.last_gpu_poll = 0.0
        self.telemetry_source_id = None

        self.loop = GLib.MainLoop()

        self.connection = None
        self.registration_id = None

        self.node_info = Gio.DBusNodeInfo.new_for_xml(
            INTROSPECTION_XML
        )

        self.interface_info = self.node_info.interfaces[0]

    def get_platform_profile(self):
        cp = self.store.load_main()

        path = cp.get(
            "general",
            "profile_path",
            fallback="/sys/firmware/acpi/platform_profile",
        )

        try:
            with open(
                path,
                "r",
                encoding="utf-8",
            ) as f:
                return f.read().strip()

        except OSError as exc:
            raise ConfigError(
                f"cannot read platform profile: {exc}"
            ) from exc

    @staticmethod
    def unpack_value(value):
        if isinstance(value, GLib.Variant):
            return AcerControlDaemon.unpack_value(value.unpack())
        if isinstance(value, dict):
            return {
                key: AcerControlDaemon.unpack_value(item)
                for key, item in value.items()
            }
        if isinstance(value, tuple):
            return tuple(
                AcerControlDaemon.unpack_value(item)
                for item in value
            )
        if isinstance(value, list):
            return [
                AcerControlDaemon.unpack_value(item)
                for item in value
            ]
        return value

    @staticmethod
    def keyboard_state_dict(state):
        state.validate()
        return {
            "mode": state.mode,
            "speed": state.speed,
            "brightness": state.brightness,
            "direction": state.direction,
            "backlight_timeout_supported": state.backlight_timeout is not None,
            "backlight_timeout": bool(state.backlight_timeout) if state.backlight_timeout is not None else False,
            "color": state.color,
            **{
                zone: state.zones[zone]
                for zone in ZONE_NAMES
            },
        }

    @staticmethod
    def keyboard_state_from_dict(values):
        values = AcerControlDaemon.unpack_value(values)
        try:
            return KeyboardState(
                mode=str(values["mode"]),
                speed=int(values["speed"]),
                brightness=int(values["brightness"]),
                direction=int(values.get("direction", 1)),
                backlight_timeout=(
                    bool(values.get("backlight_timeout", False))
                    if bool(values.get("backlight_timeout_supported", False))
                    else None
                ),
                color=str(values.get("color", "#000000")),
                zones={
                    zone: str(values[zone])
                    for zone in ZONE_NAMES
                },
            ).validate()
        except (KeyError, TypeError, ValueError) as exc:
            raise KeyboardConfigError(
                f"invalid keyboard lighting state: {exc}"
            ) from exc

    def restore_saved_keyboard_lighting(self):
        if not self.keyboard.hardware.available:
            print(
                "Keyboard RGB bridge unavailable; saved lighting not restored",
                flush=True,
            )
            return

        try:
            restored = self.keyboard.restore_default_on_start()
            if restored is not None:
                print(
                    "Keyboard lighting restored from saved configuration",
                    flush=True,
                )
        except (KeyboardHardwareError, KeyboardConfigError) as exc:
            print(
                f"Keyboard lighting restore failed: {exc}",
                file=sys.stderr,
                flush=True,
            )

    def sample_telemetry(self):
        now = time.monotonic()

        self.hardware.refresh_discovery()

        if (
            self.gpu_telemetry is None
            or (
                now - self.last_gpu_poll
                >= self.gpu_poll_interval
            )
        ):
            self.gpu_telemetry = (
                self.hardware.nvidia.read()
            )

            self.last_gpu_poll = now

        data = self.hardware.snapshot(
            gpu=self.gpu_telemetry
        )

        changed = (
            data != self.telemetry
        )

        self.telemetry = data

        if (
            changed
            and self.connection is not None
        ):
            self.connection.emit_signal(
                None,
                OBJECT_PATH,
                INTERFACE_NAME,
                "TelemetryChanged",
                GLib.Variant(
                    "(a{sv})",
                    (
                        self.variant_dict(
                            data
                        ),
                    ),
                ),
            )

        return GLib.SOURCE_CONTINUE

    def restore_saved_platform_profile(self):
        if not self.store.restore_platform_profile_on_start():
            return

        profile = (
            self.store.saved_platform_profile()
        )

        if not profile:
            return

        current = (
            self.hardware.platform_profile()
        )

        if current == profile:
            return

        try:
            self.hardware.set_platform_profile(
                profile
            )

            print(
                "Restored platform profile: "
                f"{profile}",
                flush=True,
            )

        except HardwareError as exc:
            print(
                "WARNING: cannot restore "
                "platform profile: "
                f"{exc}",
                flush=True,
            )

    def start_telemetry_sampler(self):
        if self.telemetry_source_id is not None:
            return

        # Первый snapshot сразу.
        self.sample_telemetry()

        interval_ms = max(
            100,
            round(
                self.sample_interval
                * 1000
            ),
        )

        self.telemetry_source_id = (
            GLib.timeout_add(
                interval_ms,
                self.sample_telemetry,
            )
        )

        print(
            "Telemetry sampler: "
            f"{self.sample_interval:.1f}s, "
            "NVIDIA: "
            f"{self.gpu_poll_interval:.1f}s",
            flush=True,
        )

    @staticmethod
    def variant_dict(values):
        result = {}

        for key, value in values.items():
            if value is None:
                continue

            if isinstance(value, bool):
                result[key] = GLib.Variant(
                    "b",
                    value,
                )

            elif isinstance(value, float):
                result[key] = GLib.Variant(
                    "d",
                    value,
                )

            elif isinstance(value, int):
                result[key] = GLib.Variant(
                    "i",
                    value,
                )

            elif isinstance(value, str):
                result[key] = GLib.Variant(
                    "s",
                    value,
                )

            elif (
                isinstance(value, list)
                and all(
                    isinstance(x, str)
                    for x in value
                )
            ):
                result[key] = GLib.Variant(
                    "as",
                    value,
                )

            else:
                raise TypeError(
                    f"unsupported D-Bus value "
                    f"for {key}: "
                    f"{type(value).__name__}"
                )

        return result

    def authorize(
        self,
        sender,
        action_id,
    ):
        try:
            result = subprocess.run(
                [
                    "/usr/bin/pkcheck",
                    "--action-id",
                    action_id,
                    "--system-bus-name",
                    sender,
                    "--allow-user-interaction",
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=120,
                check=False,
            )

        except subprocess.TimeoutExpired as exc:
            raise PermissionError(
                "authorization timed out"
            ) from exc

        if result.returncode != 0:
            message = result.stderr.strip()

            if not message:
                message = "authorization denied"

            raise PermissionError(
                message
            )

    def method_call(
        self,
        connection,
        sender,
        object_path,
        interface_name,
        method_name,
        parameters,
        invocation,
    ):
        try:
            if method_name == "SetPlatformProfile":
                profile = parameters.unpack()[0]

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                new_profile = (
                    self.hardware
                    .set_platform_profile(
                        profile
                    )
                )

                self.sample_telemetry()

                print(
                    "Platform profile runtime: "
                    f"{new_profile} "
                    f"by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(s)",
                        (new_profile,),
                    )
                )

                return

            if method_name == "SavePlatformProfile":
                profile = parameters.unpack()[0]

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                choices = (
                    self.hardware
                    .platform_profile_choices()
                )

                if profile not in choices:
                    raise HardwareError(
                        "unsupported platform profile: "
                        f"{profile!r}"
                    )

                saved = (
                    self.store
                    .save_platform_profile(
                        profile
                    )
                )

                print(
                    "Platform profile saved: "
                    f"{saved} "
                    f"by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(s)",
                        (saved,),
                    )
                )

                return

            if method_name == "GetSavedPlatformProfile":
                profile = (
                    self.store
                    .saved_platform_profile()
                    or ""
                )

                invocation.return_value(
                    GLib.Variant(
                        "(s)",
                        (profile,),
                    )
                )

                return

            if method_name == "GetTelemetry":
                if not self.telemetry:
                    self.sample_telemetry()

                data = self.telemetry

                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                data
                            ),
                        ),
                    )
                )

                return

            if method_name == "GetCapabilities":
                data = self.hardware.capabilities()
                keyboard_caps = self.keyboard.hardware.capabilities()
                data.update({
                    "keyboard_rgb": keyboard_caps["available"],
                    "keyboard_rgb_backend": keyboard_caps["backend"],
                    "keyboard_rgb_modes": keyboard_caps["modes"],
                    "keyboard_rgb_zones": keyboard_caps["zones"],
                    "keyboard_rgb_readback": keyboard_caps["hardware_readback"],
                    "keyboard_backlight_timeout": keyboard_caps.get(
                        "backlight_timeout", False
                    ),
                })

                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                data
                            ),
                        ),
                    )
                )

                return

            if method_name == "ListFanProfiles":
                profiles = self.store.list_profiles()

                invocation.return_value(
                    GLib.Variant(
                        "(as)",
                        (profiles,),
                    )
                )

                return

            if method_name == "GetFanProfile":
                name = parameters.unpack()[0]

                profile = self.store.load_profile(
                    name
                )

                invocation.return_value(
                    GLib.Variant(
                        "(s)",
                        (
                            profile.as_text(),
                        ),
                    )
                )

                return

            if method_name == "ValidateFanProfile":
                name, text = parameters.unpack()

                try:
                    self.store.validate_profile_text(
                        name,
                        text,
                    )

                    valid = True
                    message = "OK"

                except ConfigError as exc:
                    valid = False
                    message = str(exc)

                invocation.return_value(
                    GLib.Variant(
                        "(bs)",
                        (
                            valid,
                            message,
                        ),
                    )
                )

                return

            if method_name == "GetActiveFanProfile":
                platform_profile = (
                    self.get_platform_profile()
                )

                fan_profile = (
                    self.store.active_profile_name(
                        platform_profile
                    )
                )

                invocation.return_value(
                    GLib.Variant(
                        "(ss)",
                        (
                            platform_profile,
                            fan_profile,
                        ),
                    )
                )

                return

            if method_name == "SaveFanProfile":
                name, profile_text = parameters.unpack()

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                self.store.save_profile(
                    name,
                    profile_text,
                )

                print(
                    f"Fan profile saved: "
                    f"{name} by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(b)",
                        (True,),
                    )
                )

                return

            if method_name == "SetActiveFanProfile":
                name = parameters.unpack()[0]

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                name = self.store.set_active_profile(
                    name
                )

                print(
                    f"Active fan profile: "
                    f"{name} by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(s)",
                        (name,),
                    )
                )

                return

            if method_name == "GetFollowPlatformProfile":
                enabled = (
                    self.store
                    .follow_platform_profile()
                )

                invocation.return_value(
                    GLib.Variant(
                        "(b)",
                        (enabled,),
                    )
                )

                return

            if method_name == "SetFollowPlatformProfile":
                enabled = parameters.unpack()[0]

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                enabled = (
                    self.store
                    .set_follow_platform_profile(
                        enabled
                    )
                )

                print(
                    "Follow platform profile: "
                    f"{enabled} by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(b)",
                        (enabled,),
                    )
                )

                return

            if method_name == "DeleteFanProfile":
                name = parameters.unpack()[0]

                self.authorize(
                    sender,
                    POLKIT_ACTION_MODIFY,
                )

                self.store.delete_profile(
                    name,
                    platform_profile=(
                        self.get_platform_profile()
                    ),
                )

                print(
                    f"Fan profile deleted: "
                    f"{name} by {sender}",
                    flush=True,
                )

                invocation.return_value(
                    GLib.Variant(
                        "(b)",
                        (True,),
                    )
                )

                return

            if method_name == "GetKeyboardLighting":
                state = self.keyboard.read_hardware()
                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                self.keyboard_state_dict(state)
                            ),
                        ),
                    )
                )
                return

            if method_name == "BeginKeyboardLightingPreview":
                state = self.keyboard.read_hardware()
                self.keyboard_preview_baselines[sender] = state
                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                self.keyboard_state_dict(state)
                            ),
                        ),
                    )
                )
                return

            if method_name == "PreviewKeyboardLighting":
                self.authorize(sender, POLKIT_ACTION_MODIFY)
                values = parameters.unpack()[0]
                requested = self.keyboard_state_from_dict(values)
                if sender not in self.keyboard_preview_baselines:
                    self.keyboard_preview_baselines[sender] = (
                        self.keyboard.read_hardware()
                    )
                actual = self.keyboard.apply_preview(requested)
                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                self.keyboard_state_dict(actual)
                            ),
                        ),
                    )
                )
                return

            if method_name == "SaveKeyboardLighting":
                self.authorize(sender, POLKIT_ACTION_MODIFY)
                values = parameters.unpack()[0]
                requested = self.keyboard_state_from_dict(values)
                actual = self.keyboard.save_default(requested)
                # Save establishes a new preview baseline. Closing the window
                # after Save must not restore the old pre-save state.
                self.keyboard_preview_baselines[sender] = actual
                print(
                    f"Keyboard lighting saved by {sender}",
                    flush=True,
                )
                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                self.keyboard_state_dict(actual)
                            ),
                        ),
                    )
                )
                return

            if method_name == "CancelKeyboardLightingPreview":
                self.authorize(sender, POLKIT_ACTION_MODIFY)
                baseline = self.keyboard_preview_baselines.pop(
                    sender, None
                )
                if baseline is None:
                    actual = self.keyboard.read_hardware()
                else:
                    actual = self.keyboard.apply_preview(baseline)
                invocation.return_value(
                    GLib.Variant(
                        "(a{sv})",
                        (
                            self.variant_dict(
                                self.keyboard_state_dict(actual)
                            ),
                        ),
                    )
                )
                return

            invocation.return_dbus_error(
                "org.acer.Control.Error.UnknownMethod",
                f"Unknown method: {method_name}",
            )

        except PermissionError as exc:
            invocation.return_dbus_error(
                "org.freedesktop.DBus.Error.AccessDenied",
                str(exc),
            )

        except (HardwareError, KeyboardHardwareError) as exc:
            invocation.return_dbus_error(
                "org.acer.Control.Error.Hardware",
                str(exc),
            )

        except KeyboardConfigError as exc:
            invocation.return_dbus_error(
                "org.acer.Control.Error.Config",
                str(exc),
            )

        except ConfigError as exc:
            invocation.return_dbus_error(
                "org.acer.Control.Error.Config",
                str(exc),
            )

        except Exception as exc:
            invocation.return_dbus_error(
                "org.acer.Control.Error.Internal",
                str(exc),
            )

    def on_bus_acquired(
        self,
        connection,
        name,
    ):
        self.connection = connection

        self.registration_id = (
            connection.register_object(
                OBJECT_PATH,
                self.interface_info,
                self.method_call,
                None,
                None,
            )
        )

        if not self.registration_id:
            raise RuntimeError(
                "failed to register D-Bus object"
            )

        print(
            f"D-Bus object registered: "
            f"{OBJECT_PATH}",
            flush=True,
        )

        self.restore_saved_platform_profile()
        self.restore_saved_keyboard_lighting()
        self.start_telemetry_sampler()

    def on_name_acquired(
        self,
        connection,
        name,
    ):
        print(
            f"D-Bus name acquired: {name}",
            flush=True,
        )

    def on_name_lost(
        self,
        connection,
        name,
    ):
        print(
            f"D-Bus name lost: {name}",
            file=sys.stderr,
            flush=True,
        )

        self.loop.quit()

    def run(self):
        owner_id = Gio.bus_own_name(
            Gio.BusType.SYSTEM,
            BUS_NAME,
            Gio.BusNameOwnerFlags.NONE,
            self.on_bus_acquired,
            self.on_name_acquired,
            self.on_name_lost,
        )

        try:
            print(
                "acer-control-daemon starting",
                flush=True,
            )

            self.loop.run()

        finally:
            Gio.bus_unown_name(
                owner_id
            )


def main():
    daemon = AcerControlDaemon()

    try:
        daemon.run()

    except KeyboardInterrupt:
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
