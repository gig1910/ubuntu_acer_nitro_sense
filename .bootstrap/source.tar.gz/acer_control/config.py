import configparser
import io
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


PROFILE_NAME_RE = re.compile(
    r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$"
)


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class Paths:
    config: Path = Path(
        "/etc/acer-control/acer-control.conf"
    )

    profiles: Path = Path(
        "/etc/acer-control/fan-profiles"
    )


def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None
    )

    files = cp.read(
        path,
        encoding="utf-8",
    )

    if not files:
        raise ConfigError(
            f"cannot read configuration: {path}"
        )

    return cp


def _validate_profile_name(name: str) -> str:
    name = name.strip()

    if not PROFILE_NAME_RE.fullmatch(name):
        raise ConfigError(
            f"invalid profile name: {name!r}"
        )

    return name


def _parse_curve(
    value: str,
    *,
    key_type=float,
    label="curve",
):
    result = []
    previous = None

    for part in value.split(","):
        part = part.strip()

        if not part:
            continue

        try:
            left, right = part.split(":", 1)

            threshold = key_type(
                left.strip()
            )

            percent = int(
                right.strip()
            )

        except (ValueError, TypeError) as exc:
            raise ConfigError(
                f"invalid {label} item: {part!r}"
            ) from exc

        if not 0 <= percent <= 100:
            raise ConfigError(
                f"{label}: fan value "
                f"{percent}% is outside 0..100"
            )

        if (
            previous is not None
            and threshold <= previous
        ):
            raise ConfigError(
                f"{label}: thresholds must "
                f"be strictly increasing"
            )

        previous = threshold

        result.append(
            (threshold, percent)
        )

    if not result:
        raise ConfigError(
            f"{label} must not be empty"
        )

    return result


def _check_alpha(value: float, name: str):
    if not 0 < value <= 1:
        raise ConfigError(
            f"{name} must be in (0, 1]"
        )


def _check_nonnegative(
    value: float,
    name: str,
):
    if value < 0:
        raise ConfigError(
            f"{name} must be >= 0"
        )


class FanProfile:
    def __init__(
        self,
        name: str,
        cp: configparser.ConfigParser,
    ):
        self.name = _validate_profile_name(
            name
        )

        self.cp = cp

        self.mode = cp.get(
            "profile",
            "mode",
            fallback="",
        ).strip().lower()

        # Legacy profiles have no explicit kind and are treated as
        # built-in/system profiles. Only profiles explicitly created
        # as kind=user may be deleted from the GUI/backend.
        self.kind = cp.get(
            "profile",
            "kind",
            fallback="system",
        ).strip().lower() or "system"

        try:
            self.validate()

        except ConfigError:
            raise

        except (configparser.Error, ValueError) as exc:
            raise ConfigError(
                str(exc)
            ) from exc

    @classmethod
    def load(
        cls,
        name: str,
        paths=Paths(),
    ):
        name = _validate_profile_name(
            name
        )

        path = (
            paths.profiles
            / f"{name}.conf"
        )

        cp = _read_ini(
            path
        )

        return cls(
            name,
            cp,
        )

    @classmethod
    def from_text(
        cls,
        name: str,
        text: str,
    ):
        name = _validate_profile_name(
            name
        )

        cp = configparser.ConfigParser(
            interpolation=None
        )

        try:
            cp.read_string(
                text
            )

        except configparser.Error as exc:
            raise ConfigError(
                f"invalid INI: {exc}"
            ) from exc

        return cls(
            name,
            cp,
        )

    def validate(self):
        if "profile" not in self.cp:
            raise ConfigError(
                "missing [profile]"
            )

        declared_name = self.cp.get(
            "profile",
            "name",
            fallback="",
        ).strip()

        if declared_name != self.name:
            raise ConfigError(
                "profile name mismatch: "
                f"filename={self.name!r}, "
                f"config={declared_name!r}"
            )

        if self.kind not in (
            "system",
            "user",
        ):
            raise ConfigError(
                "profile kind must be "
                "'system' or 'user'"
            )

        if self.mode not in (
            "firmware",
            "custom",
        ):
            raise ConfigError(
                "profile mode must be "
                "'firmware' or 'custom'"
            )

        if self.mode == "firmware":
            return

        for section in (
            "cpu",
            "gpu-assist",
            "gpu",
        ):
            if section not in self.cp:
                raise ConfigError(
                    f"missing [{section}]"
                )

        cpu_curve = _parse_curve(
            self.cp.get(
                "cpu",
                "curve",
            ),
            key_type=float,
            label="CPU curve",
        )

        cpu_levels = {
            pct
            for _, pct in cpu_curve
        }

        if 100 not in cpu_levels:
            raise ConfigError(
                "CPU curve must contain "
                "a 100% level"
            )

        assist = _parse_curve(
            self.cp.get(
                "gpu-assist",
                "curve",
            ),
            key_type=int,
            label="GPU assist",
        )

        assist_map = dict(
            assist
        )

        missing = sorted(
            cpu_levels
            - set(assist_map)
        )

        if missing:
            raise ConfigError(
                "GPU assist has no mapping "
                "for CPU level(s): "
                + ", ".join(
                    map(str, missing)
                )
            )

        _parse_curve(
            self.cp.get(
                "gpu",
                "temp_curve",
            ),
            key_type=float,
            label="GPU temperature curve",
        )

        _parse_curve(
            self.cp.get(
                "gpu",
                "util_curve",
            ),
            key_type=int,
            label="GPU utilization curve",
        )

        for section, key in (
            ("cpu", "ema_alpha_up"),
            ("cpu", "ema_alpha_down"),
            ("gpu", "temp_ema_alpha_up"),
            ("gpu", "temp_ema_alpha_down"),
        ):
            _check_alpha(
                self.cp.getfloat(
                    section,
                    key,
                ),
                f"{section}.{key}",
            )

        for section, key in (
            ("cpu", "hysteresis"),
            ("cpu", "down_delay"),
            ("gpu", "native_down_delay"),
            (
                "gpu",
                "power_load_threshold",
            ),
        ):
            _check_nonnegative(
                self.cp.getfloat(
                    section,
                    key,
                ),
                f"{section}.{key}",
            )

        util_threshold = self.cp.getint(
            "gpu",
            "util_load_threshold",
        )

        if not 0 <= util_threshold <= 100:
            raise ConfigError(
                "gpu.util_load_threshold "
                "must be 0..100"
            )

        failsafe = self.cp.getint(
            "gpu",
            "telemetry_failsafe",
        )

        if not 0 <= failsafe <= 100:
            raise ConfigError(
                "gpu.telemetry_failsafe "
                "must be 0..100"
            )

        timeout = self.cp.getfloat(
            "gpu",
            "nvidia_smi_timeout",
        )

        if timeout <= 0:
            raise ConfigError(
                "gpu.nvidia_smi_timeout "
                "must be > 0"
            )

    def as_text(self) -> str:
        stream = io.StringIO()

        self.cp.write(
            stream
        )

        return stream.getvalue()


class ConfigStore:
    def __init__(
        self,
        paths=Paths(),
    ):
        self.paths = paths

    def list_profiles(self):
        result = []

        if not self.paths.profiles.is_dir():
            return result

        for path in self.paths.profiles.glob(
            "*.conf"
        ):
            name = path.stem

            try:
                _validate_profile_name(
                    name
                )

            except ConfigError:
                continue

            result.append(
                name
            )

        return sorted(
            result
        )

    def load_profile(
        self,
        name: str,
    ):
        return FanProfile.load(
            name,
            self.paths,
        )

    def validate_profile_text(
        self,
        name: str,
        text: str,
    ):
        return FanProfile.from_text(
            name,
            text,
        )

    def save_profile(
        self,
        name: str,
        text: str,
    ):
        name = _validate_profile_name(
            name
        )

        profile = FanProfile.from_text(
            name,
            text,
        )

        self.paths.profiles.mkdir(
            parents=True,
            exist_ok=True,
            mode=0o755,
        )

        target = (
            self.paths.profiles
            / f"{name}.conf"
        )

        # System profiles are package-owned templates.  The application/API
        # may create and update only kind=user profiles; package upgrades write
        # built-ins directly from install.sh.  This makes the read-only rule a
        # backend invariant rather than merely a disabled GUI button.
        if target.exists():
            existing = FanProfile.load(
                name,
                self.paths,
            )
            if existing.kind != "user":
                raise ConfigError(
                    f"system profile is read-only: {name}"
                )

        if profile.kind != "user":
            raise ConfigError(
                "only user profiles can be saved through the application"
            )

        fd, temp_name = tempfile.mkstemp(
            prefix=f".{name}.",
            suffix=".tmp",
            dir=self.paths.profiles,
            text=True,
        )

        temp_path = Path(
            temp_name
        )

        try:
            with os.fdopen(
                fd,
                "w",
                encoding="utf-8",
            ) as f:
                f.write(
                    profile.as_text()
                )

                f.flush()

                os.fsync(
                    f.fileno()
                )

            os.chmod(
                temp_path,
                0o644,
            )

            os.replace(
                temp_path,
                target,
            )

            dir_fd = os.open(
                self.paths.profiles,
                os.O_RDONLY
                | os.O_DIRECTORY,
            )

            try:
                os.fsync(
                    dir_fd
                )

            finally:
                os.close(
                    dir_fd
                )

        finally:
            if temp_path.exists():
                temp_path.unlink()

        return profile

    def load_main(self):
        return _read_ini(
            self.paths.config
        )

    def active_profile_name(
        self,
        platform_profile=None,
    ):
        cp = self.load_main()

        follow = cp.getboolean(
            "fan",
            "follow_platform_profile",
            fallback=True,
        )

        if (
            follow
            and platform_profile
        ):
            if "fan-profile-map" not in cp:
                raise ConfigError(
                    "missing [fan-profile-map]"
                )

            name = cp.get(
                "fan-profile-map",
                platform_profile,
                fallback="",
            ).strip()

            if not name:
                raise ConfigError(
                    "no fan profile mapped "
                    f"for platform profile "
                    f"{platform_profile!r}"
                )

            return _validate_profile_name(
                name
            )

        name = cp.get(
            "fan",
            "active_profile",
            fallback="",
        ).strip()

        return _validate_profile_name(
            name
        )

    def save_main(self, cp):
        target = self.paths.config
        target.parent.mkdir(
            parents=True,
            exist_ok=True,
            mode=0o755,
        )

        stream = io.StringIO()
        cp.write(stream)
        data = stream.getvalue()

        fd, temp_name = tempfile.mkstemp(
            prefix=".acer-control.",
            suffix=".tmp",
            dir=target.parent,
            text=True,
        )

        temp_path = Path(temp_name)

        try:
            with os.fdopen(
                fd,
                "w",
                encoding="utf-8",
            ) as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())

            os.chmod(temp_path, 0o644)
            os.replace(temp_path, target)

            dir_fd = os.open(
                target.parent,
                os.O_RDONLY | os.O_DIRECTORY,
            )

            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)

        finally:
            if temp_path.exists():
                temp_path.unlink()

    def set_active_profile(self, name: str):
        name = _validate_profile_name(name)

        # Заодно проверяем существование и валидность.
        self.load_profile(name)

        cp = self.load_main()

        if "fan" not in cp:
            raise ConfigError(
                "missing [fan]"
            )

        # Ручной выбор профиля означает выход
        # из режима следования platform_profile.
        cp.set(
            "fan",
            "follow_platform_profile",
            "false",
        )

        cp.set(
            "fan",
            "active_profile",
            name,
        )

        self.save_main(cp)

        return name

    def follow_platform_profile(self):
        cp = self.load_main()

        return cp.getboolean(
            "fan",
            "follow_platform_profile",
            fallback=True,
        )

    def set_follow_platform_profile(
        self,
        enabled: bool,
    ):
        cp = self.load_main()

        if "fan" not in cp:
            raise ConfigError(
                "missing [fan]"
            )

        cp.set(
            "fan",
            "follow_platform_profile",
            "true" if enabled else "false",
        )

        self.save_main(cp)

        return enabled

    def profile_references(self, name: str):
        name = _validate_profile_name(name)
        cp = self.load_main()

        refs = []

        active = cp.get(
            "fan",
            "active_profile",
            fallback="",
        ).strip()

        if active == name:
            refs.append(
                "fan.active_profile"
            )

        if "fan-profile-map" in cp:
            for platform, profile in cp[
                "fan-profile-map"
            ].items():
                if profile.strip() == name:
                    refs.append(
                        f"fan-profile-map.{platform}"
                    )

        return refs

    def _system_profile_candidate(
        self,
        candidates,
        *,
        excluding=None,
    ):
        seen = set()

        for candidate in candidates:
            if not candidate:
                continue

            try:
                candidate = _validate_profile_name(
                    str(candidate).strip()
                )
            except ConfigError:
                continue

            if candidate == excluding or candidate in seen:
                continue

            seen.add(candidate)

            try:
                profile = self.load_profile(candidate)
            except ConfigError:
                continue

            if profile.kind == "user":
                continue

            return candidate

        return None

    def _system_fallback_for_platform(
        self,
        platform_profile=None,
        *,
        excluding=None,
    ):
        cp = self.load_main()

        mapped = None
        if (
            platform_profile
            and "fan-profile-map" in cp
        ):
            mapped = cp.get(
                "fan-profile-map",
                platform_profile,
                fallback="",
            ).strip()

        candidates = [
            mapped,
            platform_profile,
            "performance",
            "balanced-performance",
            "balanced",
            "quiet",
            "low-power",
        ]

        candidates.extend(
            self.list_profiles()
        )

        return self._system_profile_candidate(
            candidates,
            excluding=excluding,
        )

    def delete_profile(
        self,
        name: str,
        *,
        platform_profile=None,
    ):
        name = _validate_profile_name(name)

        # Validate existence and type first.
        profile = self.load_profile(name)

        if profile.kind != "user":
            raise ConfigError(
                f"system profile cannot be deleted: {name}"
            )

        cp = self.load_main()

        if "fan" not in cp:
            raise ConfigError(
                "missing [fan]"
            )

        # If a user profile is referenced from the platform map, restore
        # every affected mapping to a built-in/system profile before
        # deleting the file. The natural fallback is the system profile
        # with the same name as the platform (balanced -> balanced, etc.).
        if "fan-profile-map" in cp:
            for platform, mapped in list(
                cp["fan-profile-map"].items()
            ):
                if mapped.strip() != name:
                    continue

                fallback = self._system_profile_candidate(
                    (
                        platform,
                        "performance",
                        "balanced-performance",
                        "balanced",
                        "quiet",
                        "low-power",
                        *self.list_profiles(),
                    ),
                    excluding=name,
                )

                if fallback is None:
                    raise ConfigError(
                        "cannot delete active user profile: "
                        f"no system fallback for platform {platform!r}"
                    )

                cp.set(
                    "fan-profile-map",
                    platform,
                    fallback,
                )

        active = cp.get(
            "fan",
            "active_profile",
            fallback="",
        ).strip()

        if active == name:
            # Prefer the now-safe mapping for the current platform.
            fallback = None

            if (
                platform_profile
                and "fan-profile-map" in cp
            ):
                mapped = cp.get(
                    "fan-profile-map",
                    platform_profile,
                    fallback="",
                ).strip()

                fallback = self._system_profile_candidate(
                    (mapped,),
                    excluding=name,
                )

            if fallback is None:
                fallback = self._system_fallback_for_platform(
                    platform_profile,
                    excluding=name,
                )

            if fallback is None:
                raise ConfigError(
                    "cannot delete active user profile: "
                    "no system fallback profile is available"
                )

            cp.set(
                "fan",
                "active_profile",
                fallback,
            )

            # Deleting a manually-selected user profile returns fan policy
            # to the built-in mapping for the current platform profile when
            # such a platform is known.
            if platform_profile:
                cp.set(
                    "fan",
                    "follow_platform_profile",
                    "true",
                )
            else:
                cp.set(
                    "fan",
                    "follow_platform_profile",
                    "false",
                )

        # Persist the safe fallback configuration before removing the user
        # profile file. If unlink later fails, the result is merely an
        # unreferenced user profile rather than a broken active reference.
        self.save_main(cp)

        target = (
            self.paths.profiles
            / f"{name}.conf"
        )

        try:
            target.unlink()

        except FileNotFoundError as exc:
            raise ConfigError(
                f"profile does not exist: {name}"
            ) from exc

        dir_fd = os.open(
            self.paths.profiles,
            os.O_RDONLY | os.O_DIRECTORY,
        )

        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)

        return True

    def saved_platform_profile(self):
        cp = self.load_main()

        if "platform" not in cp:
            return None

        value = cp.get(
            "platform",
            "profile",
            fallback="",
        ).strip()

        return value or None

    def restore_platform_profile_on_start(self):
        cp = self.load_main()

        return cp.getboolean(
            "platform",
            "restore_on_start",
            fallback=True,
        )

    def save_platform_profile(
        self,
        profile,
    ):
        profile = profile.strip()

        if not profile:
            raise ConfigError(
                "platform profile must not be empty"
            )

        cp = self.load_main()

        if "platform" not in cp:
            cp.add_section(
                "platform"
            )

        cp.set(
            "platform",
            "profile",
            profile,
        )

        cp.set(
            "platform",
            "restore_on_start",
            "true",
        )

        self.save_main(
            cp
        )

        return profile

