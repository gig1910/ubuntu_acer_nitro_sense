// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Acer Control RGB WMI bridge
 *
 * Companion module for Acer Control.  It does NOT replace acer_wmi and does
 * not bind to the WMI device.  It uses the exported WMI call API only.
 *
 * Target verified/probed interface:
 *   Acer Nitro AN515-58
 *   WMID GUID4 7A4DDFE7-5B5D-40B4-8595-4408E0CC7F56
 *
 * Sysfs:
 *   /sys/kernel/acer_control_rgb/dynamic
 *      read : true hardware readback via WMI method 21
 *      write: mode,speed,brightness,direction,red,green,blue
 *
 *   /sys/kernel/acer_control_rgb/zones
 *      read : true hardware readback via WMI method 7, zone masks 1/2/4/8
 *      write: RRGGBB,RRGGBB,RRGGBB,RRGGBB,brightness
 *
 *   /sys/kernel/acer_control_rgb/raw_dynamic
 *      read-only raw 16-byte response from method 21
 *
 * Nothing is persisted by the kernel module.  Persistence belongs to the
 * acer-control daemon.
 */

#include <linux/acpi.h>
#include <linux/byteorder/generic.h>
#include <linux/kernel.h>
#include <linux/kobject.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/sysfs.h>
#include <linux/unaligned.h>
#include <linux/wmi.h>

#define DRIVER_NAME "acer_control_rgb"

#define WMID_GUID3 "61EF69EA-865C-4BC3-A502-A0DEBA0CB531"
#define WMID_GUID4 "7A4DDFE7-5B5D-40B4-8595-4408E0CC7F56"

#define ACER_WMID_SET_FUNCTION                     1
#define ACER_WMID_GET_FUNCTION                     2

#define ACER_WMID_SET_GAMING_LED_METHODID          2
#define ACER_WMID_GET_GAMING_LED_METHODID          4
#define ACER_WMID_GET_GAMING_SYS_INFO_METHODID     5
#define ACER_WMID_SET_GAMING_RGB_KB_METHODID       6
#define ACER_WMID_GET_GAMING_RGB_KB_METHODID       7
#define ACER_WMID_SET_GAMING_KB_BACKLIGHT_METHODID 20
#define ACER_WMID_GET_GAMING_KB_BACKLIGHT_METHODID 21

#define DYNAMIC_PAYLOAD_LEN 16
#define DYNAMIC_GET_LEN     16
#define NUM_ZONES           4

/* Dynamic modes verified/documented by the older Acer gaming WMI interface. */
#define MODE_STATIC   0
#define MODE_BREATH   1
#define MODE_NEON     2
#define MODE_WAVE     3
#define MODE_SHIFTING 4
#define MODE_ZOOM     5

struct acer_rgb_dynamic_get {
	u8 status;
	u8 data[15];
} __packed;

struct acer_rgb_zone_set {
	u8 zone;
	u8 red;
	u8 green;
	u8 blue;
} __packed;

static struct kobject *acer_rgb_kobj;
static bool acer_timeout_attr_created;

static int acpi_obj_to_u64(const union acpi_object *obj, u64 *value)
{
	if (!obj || !value)
		return -EINVAL;

	switch (obj->type) {
	case ACPI_TYPE_INTEGER:
		*value = obj->integer.value;
		return 0;
	case ACPI_TYPE_BUFFER:
		if (obj->buffer.length >= sizeof(u64)) {
			*value = get_unaligned_le64(obj->buffer.pointer);
			return 0;
		}
		if (obj->buffer.length >= sizeof(u32)) {
			*value = get_unaligned_le32(obj->buffer.pointer);
			return 0;
		}
		return -EMSGSIZE;
	default:
		return -EPROTO;
	}
}

static int acer_wmi_call_guid_u64(
	const char *guid, u32 method, u64 input_value, u64 *result_value)
{
	struct acpi_buffer input = {
		.length = sizeof(input_value),
		.pointer = &input_value,
	};
	struct acpi_buffer output = {
		.length = ACPI_ALLOCATE_BUFFER,
		.pointer = NULL,
	};
	union acpi_object *obj;
	acpi_status status;
	int ret = 0;

	status = wmi_evaluate_method(
		guid, 0, method, &input, &output
	);
	if (ACPI_FAILURE(status))
		return -EIO;

	if (result_value) {
		obj = output.pointer;
		ret = acpi_obj_to_u64(obj, result_value);
	}

	kfree(output.pointer);
	return ret;
}

static int acer_wmi_call_u64(
	u32 method, u64 input_value, u64 *result_value)
{
	return acer_wmi_call_guid_u64(
		WMID_GUID4, method, input_value, result_value
	);
}

static int acer_rgb_get_dynamic_raw(u8 raw[DYNAMIC_GET_LEN])
{
	u64 input_value = 1;
	struct acpi_buffer input = {
		.length = sizeof(input_value),
		.pointer = &input_value,
	};
	struct acpi_buffer output = {
		.length = ACPI_ALLOCATE_BUFFER,
		.pointer = NULL,
	};
	union acpi_object *obj;
	acpi_status status;
	int ret = 0;

	status = wmi_evaluate_method(
		WMID_GUID4, 0,
		ACER_WMID_GET_GAMING_KB_BACKLIGHT_METHODID,
		&input, &output
	);
	if (ACPI_FAILURE(status))
		return -EIO;

	obj = output.pointer;
	if (!obj || obj->type != ACPI_TYPE_BUFFER) {
		ret = -EPROTO;
		goto out;
	}
	if (obj->buffer.length != DYNAMIC_GET_LEN) {
		ret = -EMSGSIZE;
		goto out;
	}

	memcpy(raw, obj->buffer.pointer, DYNAMIC_GET_LEN);

	/* Byte 0 is firmware return/status in the GET response. */
	if (raw[0] != 0)
		ret = -EIO;

out:
	kfree(output.pointer);
	return ret;
}

static int acer_rgb_set_dynamic(
	u8 mode, u8 speed, u8 brightness, u8 direction,
	u8 red, u8 green, u8 blue)
{
	u8 payload[DYNAMIC_PAYLOAD_LEN] = { 0 };
	struct acpi_buffer input;
	struct acpi_buffer output = {
		.length = ACPI_ALLOCATE_BUFFER,
		.pointer = NULL,
	};
	union acpi_object *obj;
	acpi_status status;
	u64 firmware_status = 0;
	int ret = 0;

	/*
	 * Payload follows the reverse-engineered PredatorSense/facer protocol.
	 * byte 3 = 8 for Wave, otherwise 0
	 * byte 9 = 1 marks the config active.
	 */
	payload[0] = mode;
	payload[1] = speed;
	payload[2] = brightness;
	payload[3] = (mode == MODE_WAVE) ? 8 : 0;
	payload[4] = direction;
	payload[5] = red;
	payload[6] = green;
	payload[7] = blue;
	payload[9] = 1;

	input.length = sizeof(payload);
	input.pointer = payload;

	status = wmi_evaluate_method(
		WMID_GUID4, 0,
		ACER_WMID_SET_GAMING_KB_BACKLIGHT_METHODID,
		&input, &output
	);
	if (ACPI_FAILURE(status))
		return -EIO;

	obj = output.pointer;
	if (obj) {
		ret = acpi_obj_to_u64(obj, &firmware_status);
		if (ret == -EMSGSIZE || ret == -EPROTO)
			ret = 0; /* Some firmware returns an empty/odd success object. */
	}

	kfree(output.pointer);

	if (ret)
		return ret;
	if (firmware_status != 0)
		return -EIO;

	return 0;
}

static int acer_rgb_prepare_static(void)
{
	u64 ignored;
	int ret;

	/*
	 * This polling/enable sequence is the one tested by the 2026 AN515-58
	 * acer-wmi RGB RFC and by the older facer implementation.
	 */
	ret = acer_wmi_call_u64(
		ACER_WMID_GET_GAMING_SYS_INFO_METHODID,
		0, &ignored
	);
	if (ret)
		return ret;

	return acer_wmi_call_u64(
		ACER_WMID_GET_GAMING_LED_METHODID,
		8ULL | (15ULL << 40),
		NULL
	);
}

static int acer_rgb_set_zone(u8 zone_mask, u8 red, u8 green, u8 blue)
{
	struct acer_rgb_zone_set params = {
		.zone = zone_mask,
		.red = red,
		.green = green,
		.blue = blue,
	};
	struct acpi_buffer input = {
		.length = sizeof(params),
		.pointer = &params,
	};
	struct acpi_buffer output = {
		.length = ACPI_ALLOCATE_BUFFER,
		.pointer = NULL,
	};
	union acpi_object *obj;
	u64 firmware_status = 0;
	acpi_status status;
	int ret = 0;

	status = wmi_evaluate_method(
		WMID_GUID4, 0,
		ACER_WMID_SET_GAMING_RGB_KB_METHODID,
		&input, &output
	);
	if (ACPI_FAILURE(status))
		return -EIO;

	obj = output.pointer;
	if (obj) {
		ret = acpi_obj_to_u64(obj, &firmware_status);
		if (ret == -EMSGSIZE || ret == -EPROTO)
			ret = 0;
	}
	kfree(output.pointer);

	if (ret)
		return ret;
	if (firmware_status != 0)
		return -EIO;

	return 0;
}

static int acer_rgb_get_zone(u8 zone_mask, u32 *rgb)
{
	u64 raw = 0;
	u64 converted;
	int ret;

	ret = acer_wmi_call_u64(
		ACER_WMID_GET_GAMING_RGB_KB_METHODID,
		zone_mask, &raw
	);
	if (ret)
		return ret;

	/*
	 * Acer returns the color packed in the upper half after byte swapping.
	 * This is the same conversion used by Linuwu-Sense get_per_zone_color().
	 */
	converted = be64_to_cpu((__force __be64)raw) >> 32;
	*rgb = converted & 0x00ffffff;

	return 0;
}

static int validate_dynamic(
	unsigned int mode, unsigned int speed, unsigned int brightness,
	unsigned int direction, unsigned int red, unsigned int green,
	unsigned int blue)
{
	if (mode > MODE_ZOOM)
		return -ERANGE;
	if (speed > 9)
		return -ERANGE;
	if (brightness > 100)
		return -ERANGE;
	if (direction > 2)
		return -ERANGE;
	if (red > 255 || green > 255 || blue > 255)
		return -ERANGE;

	if ((mode == MODE_WAVE || mode == MODE_SHIFTING) &&
	    direction != 1 && direction != 2)
		return -EINVAL;

	return 0;
}

static ssize_t dynamic_show(
	struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	u8 raw[DYNAMIC_GET_LEN];
	struct acer_rgb_dynamic_get *state;
	int ret;

	ret = acer_rgb_get_dynamic_raw(raw);
	if (ret)
		return ret;

	state = (struct acer_rgb_dynamic_get *)raw;

	return sysfs_emit(
		buf, "%u,%u,%u,%u,%u,%u,%u\n",
		state->data[0], /* mode */
		state->data[1], /* speed */
		state->data[2], /* brightness */
		state->data[4], /* direction */
		state->data[5], /* red */
		state->data[6], /* green */
		state->data[7]  /* blue */
	);
}

static ssize_t dynamic_store(
	struct kobject *kobj, struct kobj_attribute *attr,
	const char *buf, size_t count)
{
	unsigned int mode, speed, brightness, direction;
	unsigned int red, green, blue;
	int parsed, ret;

	parsed = sscanf(
		buf, "%u,%u,%u,%u,%u,%u,%u",
		&mode, &speed, &brightness, &direction,
		&red, &green, &blue
	);
	if (parsed != 7)
		return -EINVAL;

	ret = validate_dynamic(
		mode, speed, brightness, direction,
		red, green, blue
	);
	if (ret)
		return ret;

	ret = acer_rgb_set_dynamic(
		mode, speed, brightness, direction,
		red, green, blue
	);
	if (ret)
		return ret;

	return count;
}

static ssize_t raw_dynamic_show(
	struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	u8 raw[DYNAMIC_GET_LEN];
	int ret, i;
	ssize_t len = 0;

	ret = acer_rgb_get_dynamic_raw(raw);
	if (ret)
		return ret;

	for (i = 0; i < DYNAMIC_GET_LEN; i++)
		len += sysfs_emit_at(buf, len, "%02x%s", raw[i],
				     i == DYNAMIC_GET_LEN - 1 ? "\n" : " ");

	return len;
}

static ssize_t zones_show(
	struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	static const u8 masks[NUM_ZONES] = { 1, 2, 4, 8 };
	u32 rgb[NUM_ZONES];
	u8 raw[DYNAMIC_GET_LEN];
	struct acer_rgb_dynamic_get *state;
	int ret, i;

	for (i = 0; i < NUM_ZONES; i++) {
		ret = acer_rgb_get_zone(masks[i], &rgb[i]);
		if (ret)
			return ret;
	}

	ret = acer_rgb_get_dynamic_raw(raw);
	if (ret)
		return ret;
	state = (struct acer_rgb_dynamic_get *)raw;

	return sysfs_emit(
		buf, "%06x,%06x,%06x,%06x,%u\n",
		rgb[0], rgb[1], rgb[2], rgb[3],
		state->data[2]
	);
}

static ssize_t zones_store(
	struct kobject *kobj, struct kobj_attribute *attr,
	const char *buf, size_t count)
{
	static const u8 masks[NUM_ZONES] = { 1, 2, 4, 8 };
	unsigned int rgb[NUM_ZONES];
	unsigned int brightness;
	int parsed, ret, i;

	parsed = sscanf(
		buf, "%x,%x,%x,%x,%u",
		&rgb[0], &rgb[1], &rgb[2], &rgb[3],
		&brightness
	);
	if (parsed != 5)
		return -EINVAL;

	if (brightness > 100)
		return -ERANGE;
	for (i = 0; i < NUM_ZONES; i++)
		if (rgb[i] > 0x00ffffff)
			return -ERANGE;

	ret = acer_rgb_prepare_static();
	if (ret)
		return ret;

	/*
	 * Apply per-zone colors first, then explicitly put the controller into
	 * Static mode with the requested brightness.  This mirrors the tested
	 * facer user-space sequence for AN515-58.
	 */
	for (i = 0; i < NUM_ZONES; i++) {
		ret = acer_rgb_set_zone(
			masks[i],
			(rgb[i] >> 16) & 0xff,
			(rgb[i] >> 8) & 0xff,
			rgb[i] & 0xff
		);
		if (ret)
			return ret;
	}

	ret = acer_rgb_set_dynamic(
		MODE_STATIC, 0, brightness, 0, 0, 0, 0
	);
	if (ret)
		return ret;

	return count;
}

static int acer_backlight_timeout_get(bool *enabled)
{
	u64 result = 0;
	u8 timeout_seconds;
	int ret;

	ret = acer_wmi_call_guid_u64(
		WMID_GUID3, ACER_WMID_GET_FUNCTION, 0x88401ULL, &result
	);
	if (ret)
		return ret;

	/*
	 * Firmware generations return slightly different payloads here.
	 * Older implementations were observed as:
	 *   enabled : 0x1e0000080000
	 *   disabled: 0x000000080000
	 *
	 * AN515-58 firmware returns, for example:
	 *   0x1e6400000000
	 * where byte 5 still contains the 30-second timeout (0x1e),
	 * while other bytes carry firmware-specific state.  Therefore do not
	 * compare the whole u64; decode only the timeout byte.
	 */
	timeout_seconds = (result >> 40) & 0xff;

	if (timeout_seconds == 0) {
		*enabled = false;
		return 0;
	}
	if (timeout_seconds == 30) {
		*enabled = true;
		return 0;
	}

	pr_warn(
		"unexpected keyboard timeout readback: 0x%llx (timeout=%u s)\n",
		result, timeout_seconds
	);
	return -EIO;
}

static int acer_backlight_timeout_set(bool enabled)
{
	u64 result = 0;
	bool readback;
	int ret;

	ret = acer_wmi_call_guid_u64(
		WMID_GUID3, ACER_WMID_SET_FUNCTION,
		enabled ? 0x1E0000088402ULL : 0x88402ULL,
		&result
	);
	if (ret)
		return ret;

	/* Verify the firmware state instead of trusting the SET return object. */
	ret = acer_backlight_timeout_get(&readback);
	if (ret)
		return ret;
	if (readback != enabled)
		return -EIO;

	return 0;
}

static ssize_t backlight_timeout_show(
	struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	bool enabled;
	int ret = acer_backlight_timeout_get(&enabled);

	if (ret)
		return ret;

	return sysfs_emit(buf, "%u\n", enabled ? 1 : 0);
}

static ssize_t backlight_timeout_store(
	struct kobject *kobj, struct kobj_attribute *attr,
	const char *buf, size_t count)
{
	unsigned int value;
	int ret;

	ret = kstrtouint(buf, 0, &value);
	if (ret)
		return ret;
	if (value > 1)
		return -ERANGE;

	ret = acer_backlight_timeout_set(value != 0);
	if (ret)
		return ret;

	return count;
}

static ssize_t capabilities_show(
	struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return sysfs_emit(
		buf,
		"guid=%s zones=4 modes=static,breath,neon,wave,shifting,zoom "
		"dynamic_readback=1 zone_readback=1 backlight_timeout=%u "
		"timeout_seconds=30\n",
		WMID_GUID4, wmi_instance_count(WMID_GUID3) > 0 ? 1 : 0
	);
}

static struct kobj_attribute dynamic_attr =
	__ATTR(dynamic, 0644, dynamic_show, dynamic_store);
static struct kobj_attribute zones_attr =
	__ATTR(zones, 0644, zones_show, zones_store);
static struct kobj_attribute raw_dynamic_attr =
	__ATTR(raw_dynamic, 0444, raw_dynamic_show, NULL);
static struct kobj_attribute capabilities_attr =
	__ATTR(capabilities, 0444, capabilities_show, NULL);
static struct kobj_attribute backlight_timeout_attr =
	__ATTR(backlight_timeout, 0644,
	       backlight_timeout_show, backlight_timeout_store);

static struct attribute *acer_rgb_attrs[] = {
	&dynamic_attr.attr,
	&zones_attr.attr,
	&raw_dynamic_attr.attr,
	&capabilities_attr.attr,
	NULL,
};

static const struct attribute_group acer_rgb_group = {
	.attrs = acer_rgb_attrs,
};

static int __init acer_control_rgb_init(void)
{
	int instances;
	int ret;

	instances = wmi_instance_count(WMID_GUID4);
	if (instances <= 0) {
		pr_err("Acer gaming RGB WMI GUID not found\n");
		return -ENODEV;
	}

	acer_rgb_kobj = kobject_create_and_add(
		"acer_control_rgb", kernel_kobj
	);
	if (!acer_rgb_kobj)
		return -ENOMEM;

	ret = sysfs_create_group(acer_rgb_kobj, &acer_rgb_group);
	if (ret) {
		kobject_put(acer_rgb_kobj);
		acer_rgb_kobj = NULL;
		return ret;
	}

	if (wmi_instance_count(WMID_GUID3) > 0) {
		ret = sysfs_create_file(
			acer_rgb_kobj, &backlight_timeout_attr.attr
		);
		if (ret) {
			sysfs_remove_group(acer_rgb_kobj, &acer_rgb_group);
			kobject_put(acer_rgb_kobj);
			acer_rgb_kobj = NULL;
			return ret;
		}
		acer_timeout_attr_created = true;
	}

	pr_info(
		"loaded; RGB GUID present (%d instance%s), keyboard timeout=%s, "
		"sysfs at /sys/kernel/acer_control_rgb\n",
		instances, instances == 1 ? "" : "s",
		acer_timeout_attr_created ? "yes" : "no"
	);

	return 0;
}

static void __exit acer_control_rgb_exit(void)
{
	if (acer_rgb_kobj) {
		if (acer_timeout_attr_created)
			sysfs_remove_file(
				acer_rgb_kobj, &backlight_timeout_attr.attr
			);
		sysfs_remove_group(acer_rgb_kobj, &acer_rgb_group);
		kobject_put(acer_rgb_kobj);
	}

	pr_info("unloaded\n");
}

module_init(acer_control_rgb_init);
module_exit(acer_control_rgb_exit);

MODULE_AUTHOR("Acer Control project");
MODULE_DESCRIPTION("Acer Nitro/Predator 4-zone RGB WMI bridge");
MODULE_LICENSE("GPL");
MODULE_VERSION("0.3");
