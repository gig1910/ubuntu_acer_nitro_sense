#!/bin/bash
set -Eeuo pipefail

MODULE_NAME="acer-control-rgb"
MODULE_VERSION="0.3"
MODULE_KO="acer_control_rgb_bridge"
SIGN_CONF="/etc/dkms/framework.conf.d/90-acer-control-signing.conf"
PURGE=0

for arg in "$@"; do
    case "$arg" in
        --purge) PURGE=1 ;;
        -h|--help)
            echo "Usage: sudo ./uninstall.sh [--purge]"
            echo "Without --purge, /etc/acer-control is preserved."
            exit 0
            ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done

if (( EUID != 0 )); then
    echo "Run as root: sudo ./uninstall.sh" >&2
    exit 1
fi

systemctl disable --now acer-control-daemon.service 2>/dev/null || true
rm -f /etc/systemd/system/acer-control-daemon.service

modprobe -r "$MODULE_KO" 2>/dev/null || true
if command -v dkms >/dev/null 2>&1; then
    dkms remove -m "$MODULE_NAME" -v "$MODULE_VERSION" --all 2>/dev/null || true
fi
rm -rf "/usr/src/${MODULE_NAME}-${MODULE_VERSION}"
rm -f /etc/modules-load.d/acer-control-rgb.conf

rm -rf /usr/local/lib/acer-control
rm -f /usr/local/bin/acer-control /usr/local/bin/acer-control-settings /usr/local/bin/acer-control-diagnose
rm -f /usr/local/sbin/acer-control-uninstall

rm -f /usr/share/dbus-1/system.d/org.acer.Control.conf
rm -f /usr/share/polkit-1/actions/org.acer.control.policy
rm -f /etc/polkit-1/rules.d/49-acer-control.rules
rm -f /usr/share/applications/org.acer.Control.UI.desktop
rm -f /usr/share/applications/org.acer.Control.UI.Settings.desktop

for size in 16 22 24 32 48 64 96 128 256 512 1024; do
    rm -f "/usr/share/icons/hicolor/${size}x${size}/apps/org.acer.Control.UI.png"
done

if [[ -f "$SIGN_CONF" ]] && grep -q '^# Managed by Acer Control installer\.$' "$SIGN_CONF"; then
    rm -f "$SIGN_CONF"
fi

if (( PURGE )); then
    rm -rf /etc/acer-control
else
    echo "Preserved: /etc/acer-control"
fi

systemctl daemon-reload
systemctl reload dbus.service 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database /usr/share/applications || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -f -t /usr/share/icons/hicolor >/dev/null 2>&1 || true

echo "Acer Control uninstalled."
echo "Legacy /usr/local/sbin/acer-fan-control, if present, was intentionally not modified."
